import javax.swing.*;
import java.awt.*;

public class ControlGamePanel extends JPanel {
    public ControlGamePanel() {
        setBackground(Color.red);
    }
}
