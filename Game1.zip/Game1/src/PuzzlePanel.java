import javax.swing.*;
import java.awt.*;

public class PuzzlePanel extends JPanel {
    public PuzzlePanel() {
        setBackground(Color.blue);
    }
}
